package com.qiniu.storage.model;

/**
 * Created by bailong on 15/2/22.
 */
public final class BatchStatus {
    public int code;
}
