阿里百川多媒体服务  Python SDK说明文档
===============================================================
阿里百川开放云服务官方网站:
    [http://wantu.taobao.com](http://wantu.taobao.com)

阿里百川多媒体服务简介
===============================================================
图片、短视频等多媒体资源的流畅度和稳定性是影响 App 用户体验的关键。
为助力无线开发者轻松打造最流畅的 App，友盟携手阿里百川推出了“多媒体服务”（花名“顽兔”，“玩图”的谐音）。

文档说明
===============================================================
这篇文档主要介绍如何使用Python来进行顽兔多媒体服务API调用。
这篇文档假设你已经熟悉Python，熟悉顽兔多媒体服务的相关概念，并且已经注册了
顽兔多媒体服务服务。
如果你还没有开通或者还不了解顽兔多媒体服务，请移步TAE顽兔多媒体服务官方网站。

环境要求
===============================================================
Python SDK需要：安装python 2.5（包括）以上且在3.0（不包括）以下
的版本。
可以在Windows平台和Linux平台使用。



# 安装说明

    python setup.py install


# SDK说明

## 1、约定

1.本API在设计时；

2.用户的 Token 生成请务必放在服务端进行，严防 SK 泄露；

3.上传文件使用 MultiPart 的方式，每个上传参数都作为单独的 Part 出现；

4.文件一定作为最后一个 Part，否则文件之后的 Part 部分将丢失；

5.Token 的过期时间由用户通过时间戳指定，如果 401 错误频发，请确保您的服务器时间与顽兔的时间同步。

## 2、SDK 上传接口

### 2.1 统一说明

所有接口都是集成到 Want 类中。 返回值为 json 结构。根据 json 中 code 是否为200  判断是否调用成功。例如：

	{
	'code': 200,
	 'name': 'test.jpg',
	 'url':'http://xxx/test/test.jpg',
	 'request_id': '07db0514-d7bb-4785-8b34-6697e3aee52f',
	 'file_size': '1056344',
	 'file_modified': 1437535493816,
	 'e_tag': '81FCC17FBB190BCA4EC1E9A3DEF02E57',
	 'message': 'OK',
	 'mime_type': 'image/jpeg',
	 'dir': '/test'
	 }


出错返回示例：

    {
    'message': 'InternalError',
    'code': 500,
    'request_id': 'fe6b0382-c12d-413a-a70b-66745ae76442'
    }


### 2.2 上传策略

上传策略是提供给开发者用于控制上传相关行为与限制的一个配置设定。为了防止传输过程中对上传策略进行篡改，上传策略将作为签名字段包含在 Authorizaton HTTP Header 中。（详见上传凭证一节）
编码前的上传策略是 JSON 格式的，示例如下：

JSON 格式

    {
        "callbackBody":     "<string>",
        "callbackBodyType": "<string>",
        "callbackHost":     "<string>",
        "callbackUrl":      "<string>",
        "detectMime":       "<int>",
        "dir":              "<string>",
        "expiration":       "<long>",
        "insertOnly":       "<int>",
        "mimeLimit":        "<string>",
        "name":             "<string>",
        "namespace":        "<string>",
        "returnBody":       "<string>",
        "returnUrl":        "<string>",
        "sizeLimit":        "<long>"
    }

各上传策略的字段描述详见下表：

<table border="0" cellpadding="0" cellspacing="0"> 
  <tbody> 
   <tr> 
    <td>

参数
</td> 
    <td>

说明
</td> 
   </tr> 
   <tr> 
    <td>

namespace
</td> 
    <td>

存储服务ID，开发者创建空间时指定的空间唯一标示。type = TOP 时必填
</td> 
   </tr> 
   <tr> 
    <td>

bucket
</td> 
    <td>

可忽略
</td> 
   </tr> 
   <tr> 
    <td>

expiration
</td> 
    <td>

token的过期时间,unixtime,单位毫秒。举例如下:

(System.currentTimeMillis() + 3600 * 1000)
</td> 
   </tr> 
   <tr> 
    <td>

insertOnly
</td> 
    <td>

文件上传是否可覆盖

0: 可覆盖, 1: 不可覆盖

默认为可覆盖的模式
</td> 
   </tr> 
   <tr> 
    <td>

dir
</td> 
    <td>

指定上传文件的存储路径

如果不指定则会使用接口中传入的dir参数

如果接口中也没有传入dir参数,则默认使用根目录
</td> 
   </tr> 
   <tr> 
    <td>

name
</td> 
    <td>

指定上传文件的存储文件名
</td> 
   </tr> 
   <tr> 
    <td>

sizeLimit
</td> 
    <td>

指定上传文件大小的最大值(单位:字节)

各种资源类型文件大小的系统限制

图片: 10485760 (10Mb: 10 * 1024 * 1024)

默认情况下使用系统限制检查文件大小
</td> 
   </tr> 
   <tr> 
    <td>

detectMime
</td> 
    <td>

是否自动检查文件头部信息

0: 不自动检查, 1: 自动检查

默认为自动检查文件头部信息
</td> 
   </tr> 
   <tr> 
    <td>

mimeLimit
</td> 
    <td>

指定上传文件类型的限制(MimeType类型)

允许指定多种类型, 请使用';'隔开

各种资源类型允许上传的MimeType类型

图片:

jpg: image/jpeg

png: image/png

bmp: image/bmp

gif: image/gif

通配符: image/*
</td> 
   </tr> 
   <tr> 
    <td>

callbackUrl
</td> 
    <td>

图片上传完成之后,系统回调该Url
</td> 
   </tr> 
   <tr> 
    <td>

callbackHost
</td> 
    <td>

在系统回调时,将设置请求头部的Host信息

设置该参数之前应该首先设置callbackUrl
</td> 
   </tr> 
   <tr> 
    <td>

callbackBody
</td> 
    <td>

在系统回调时,将设置请求的Body信息

设置该参数之前应该首先设置callbackUrl

该参数可以包含占位符
</td> 
   </tr> 
   <tr> 
    <td>

callbackBodyType
</td> 
    <td>

在系统回调时,将设置请求的Body类型

设置该参数之前应该首先设置callbackUrl

设置该参数之前应该首先设置callbackBody
</td> 
   </tr> 
  </tbody> 
 </table> 

### 2.3 占位符

上传策略中有些策略（例如 dir、callbackBody 等可以包含类似系统时间、图片长宽、用户自定义变量等信息），在开发者编写上传策略的时候并不知道具体值，这时，可以通过占位符(${占位符名称})进行表示，由顽兔多媒体服务在运行时进行渲染填充。

例如: 可以在上传策略中指定文件名为 ${year}-${month}-${day}.jpg , 运行时生成的文件名可能就会是这样 2015-2-5.jpg

目前支持的占位符如下列表：

<table border="0" cellpadding="0" cellspacing="0"> 
 <tbody> 
  <tr> 
   <td>占位符名</td> 
   <td>说明</td> 
  </tr> 
  <tr> 
   <td>namespace</td> 
   <td>开发者创建空间时指定的空间唯一标示</td> 
  </tr> 
  <tr> 
   <td>dir</td> 
   <td>文件路径(不可以用来渲染dir和name)</td> 
  </tr> 
  <tr> 
   <td>name</td> 
   <td>文件名(不可以用来渲染dir和name)</td> 
  </tr> 
  <tr> 
   <td>mimeType</td> 
   <td>文件类型(MimeType) (中间有'/', 请不要用于渲染name)</td> 
  </tr> 
  <tr> 
   <td>mediaType</td> 
   <td>文件MIME前缀, 多媒体文件类型(取自MimeType)</td> 
  </tr> 
  <tr> 
   <td>ext</td> 
   <td>文件MIME后缀, 文件扩展名(取自MimeType)</td> 
  </tr> 
  <tr> 
   <td>year</td> 
   <td>上传时间的年份</td> 
  </tr> 
  <tr> 
   <td>month</td> 
   <td>上传时间的月份</td> 
  </tr> 
  <tr> 
   <td>day</td> 
   <td>上传时间的日期</td> 
  </tr> 
  <tr> 
   <td>hour</td> 
   <td>上传时间的小时(24小时制)</td> 
  </tr> 
  <tr> 
   <td>minute</td> 
   <td>上传时间的分</td> 
  </tr> 
  <tr> 
   <td>second</td> 
   <td>上传时间的秒</td> 
  </tr> 
  <tr> 
   <td>fileSize</td> 
   <td>上传文件的大小</td> 
  </tr> 
  <tr> 
   <td>width</td> 
   <td>图片宽</td> 
  </tr> 
  <tr> 
   <td>height</td> 
   <td>图片高</td> 
  </tr> 
  <tr> 
   <td>exif</td> 
   <td>图片的Exif信息，里面包含了诸多子项可以通过exif.xxx来获取</td> 
  </tr> 
  <tr> 
   <td>自定义占位符var-*</td> 
   <td>用户自定义占位符("var-"为参数前缀, "*"为用户用于渲染的自定义占位符名)，包含在上传参数中</td> 
  </tr> 
  <tr> 
   <td>自定义元信息meta-*</td> 
   <td>用户自定义的文件meta信息("meta-"为参数前缀, "*"为用户用于渲染的自定义Meta信息名) ，包含在上传参数中</td> 
  </tr> 
 </tbody> 
</table>

注意:

<span style="color:red">当发生重名时, 会以该顺序进行选择: 系统占位符、用户自定义文件meta占位符、用户自定义占位符。在上传的时候, 如果需要指定一个名称为cat的占位符, 需要使用名称为var-cat的参数声明该自定义占位符；meta则对应meta-cat。</span>

### 2.4 初始化图片操作对象

    from want import Wan
    image  = Want(ak, sk, type, upload_endpoint, manage_endpoint)

**初始化传入参数:**

AK: 开发者的AccessKeyId

SK: 开发者的AccessKeySecret

type: 开发者的服务类型(即AK/SK的颁发类型，百川用户都是TOP)，可不填写。

`upload_endpoint`和`manage_endpoint`一般不需要填写，使用默认值即可。

### 2.5 小文件上传
建议10M以下的文件采用此种方式。

**小文件上传**

    upload_file( policy, dir, name, file_path, md5=None, meta={}, var={})
    
    参数说明：
    policy  - 上传策略
    dir - 上传文件的存储路径
    name - 上传文件的存储文件名
    file_path - 要上传的本地文件路径
    md5 - 文件md5值（可选）
    meta - meta信息（可选）
    var - 自定义kv信息对（可选）

返回结果：

    {
	'code': 200,
	 'name': 'test.jpg',
	 'url':'http://xxx/test/test.jpg',
	 'request_id': '07db0514-d7bb-4785-8b34-6697e3aee52f',
	 'file_size': '1056344',
	 'file_modified': 1437535493816,
	 'e_tag': '81FCC17FBB190BCA4EC1E9A3DEF02E57',
	 'message': 'OK',
	 'mime_type': 'image/jpeg',
	 'dir': '/test'
    }


出错返回示例：

    {
    'message': 'InternalError',
    'code': 500,
    'request_id': 'fe6b0382-c12d-413a-a70b-66745ae76442'
    }

**小文件上传(byContent)**

    upload_content( policy, dir, name, content, md5=None, meta={}, var={})
    
    参数说明：
    policy  - 上传策略
    dir - 上传文件的存储路径
    name - 上传文件的存储文件名
    content - 要上传文件的输入流
    md5 - 文件md5值（可选）
    meta - meta信息（可选）
    var - 自定义kv信息对（可选）

返回结果：

    {
	'code': 200,
	 'name': 'test.jpg',
	 'url':'http://xxx/test/test.jpg',
	 'request_id': '07db0514-d7bb-4785-8b34-6697e3aee52f',
	 'file_size': '1056344',
	 'file_modified': 1437535493816,
	 'e_tag': '81FCC17FBB190BCA4EC1E9A3DEF02E57',
	 'message': 'OK',
	 'mime_type': 'image/jpeg',
	 'dir': '/test'
    }


出错返回示例：

    {
    'message': 'InternalError',
    'code': 500,
    'request_id': 'fe6b0382-c12d-413a-a70b-66745ae76442'
    }

### 2.6 分片上传
建议上传大文件时采用此种方式。注：每块分片大小需大于100KB。

**创建分片上传任务**

    multipart_init( policy, dir, name, content, md5=None, meta={}, var={})
    
    参数说明：
    policy  - 上传策略
    dir - 上传文件的存储路径
    name - 上传文件的存储文件名
    content - 要上传文件的输入流
    md5 - 文件md5值（可选）
    meta - meta信息（可选）
    var - 自定义kv信息对（可选）

返回结果：

    {
    'code': 200,
    'name': 'test.jpg',
    'part_number': 1,  //上传块编号 分片初始化为1
    'id': 'ae794009-d5dc-43a7-937a-612f2e42b04d', //上传唯一id，上传分片内容时作为参数传递
    'upload_id': '45DED2452BB348E7865FF56CE8C603E2', //分片上传任务id，上传分片内容时作为参数传递
    'request_id': '38b6a5fb-9ed7-419d-ae52-43f393561b89',
    'message': 'OK',
    'dir': '/test',
    'e_tag': '61C245076C1B75BB4705A172C0605FA3' //上传部分的md5值，分片任务完成时需要用该字段验证
    }

出错返回示例：

    {
    'message': 'InternalError',
    'code': 500,
    'request_id': 'fe6b0382-c12d-413a-a70b-66745ae76442'
    }


**分片上传**

    multipart_upload(policy, id, upload_id, part_number, content, md5=None)
    
    参数说明：
    policy  - 上传策略
    id - 上传唯一id（初始化分片任务时返回）
    upload_id - 分片上传id（初始化分片任务时返回）
    part_number - 上传块编号（分片任务初始块编号为1，之后每次上传编号加1）
    content - 要上传文件的输入流
    md5 - 完整文件的md5值（可选）

返回结果：

    {
    'code': 200,
    'name': 'test.jpg',
    'part_number': 1,  //上传块编号 分片初始化为1
    'id': 'ae794009-d5dc-43a7-937a-612f2e42b04d', //上传唯一id，上传分片内容时作为参数传递
    'upload_id': '45DED2452BB348E7865FF56CE8C603E2', //分片上传任务id，上传分片内容时作为参数传递
    'request_id': '38b6a5fb-9ed7-419d-ae52-43f393561b89',
    'message': 'OK',
    'dir': '/test',
    'e_tag': '61C245076C1B75BB4705A172C0605FA3' //上传部分的md5值，分片任务完成时需要用该字段验证
    }

出错返回示例：

    {
    'message': 'InternalError',
    'code': 500,
    'request_id': 'fe6b0382-c12d-413a-a70b-66745ae76442'
    }

**完成分片上传任务**

    multipart_complete(policy, id, upload_id, parts, md5=None)
    
    参数说明：
    policy  - 上传策略
    id - 上传唯一id（初始化分片任务时返回）
    upload_id - 分片上传id（初始化分片任务时返回）
    parts - 每个分片md5值组成的json数组，需要进行base64的编码.例如：base64.urlsafe_b64encode(json.dumps([{'e_tag': '分片1返回的e_tag', 'part_number': 1}, {'e_tag': '分片2返回的e_tag', 'part_number': 2},
             {'e_tag': '分片3返回的e_tag', 'part_number': 3}]))
    md5 - 完整文件的md5值（可选）

返回结果：

    {
    'code': 200,
    'name': 'test.jpg',
    'url': 'http://xxx.image.alimmdn.com/test/test.jpg',
    'file_size': '1056344',
    'file_modified': 1437967420625,
    'upload_id': '45DED2452BB348E7865FF56CE8C603E2',
    'request_id': '8628d171-4953-4704-8443-f89e0790a0db',
    'message': 'OK',
    'mime_type': 'image/jpeg',
    'dir': '/test'
    }


出错返回示例：

    {
    'message': 'InternalError',
    'code': 500,
    'request_id': 'fe6b0382-c12d-413a-a70b-66745ae76442'
    }

**取消分片上传任务**

    multipart_cancel(policy, id, upload_id)
    
    参数说明：
    policy  - 上传策略
    id - 上传唯一id（初始化分片任务时返回）
    upload_id - 分片上传id（初始化分片任务时返回）
    
    返回结果： 无


ChangeHistory
===============================================================
0.1.0   -   2015-07-10
* 初始版本 by 晨秋


