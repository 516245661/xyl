#!/usr/bin/env python
#coding=utf-8
#

from want import Want, utils
import time
import os
import json


def test_upload(ps):
    with open('/Temp/1.JPG','rb') as f:
        content = f.read()
        ##测试文件内容上传
        ws.upload_content(ps,'/test/pyt','wyll.jpg',content)
        ##测试文件上传
        ws.upload_file(ps, '/test/pyt', 'wyll.jpg', '/Temp/1.JPG')


def test_part(ps):
    ####分片
    size = os.stat('/Temp/1.JPG','rb').st_size
    part_size = size / 3
    with open('/Temp/1.JPG') as f:
        c1 = f.read(part_size)
        c2 = f.read(part_size)
        c3 = f.read()
    r1 = ws.multipart_init(ps, '/test/pyt', 'fpinit.jpg', c1) #开始
    r2 = ws.multipart_upload(ps, r1.get('id'), r1.get('upload_id'), 2, c2)  #上传分片2
    r3 = ws.multipart_upload(ps, r1.get('id'), r1.get('upload_id'), 3, c3) #上传分片3
    #
    parts = [{'e_tag': r1.get('e_tag'), 'part_number': 1}, {'e_tag': r2.get('e_tag'), 'part_number': 2},
             {'e_tag': r3.get('e_tag'), 'part_number': 3}]
    r4 = ws.multipart_complete(ps, r1.get('id'), r1.get('upload_id'), parts)  #分片上传完成
    #rcancel = ws.multipart_cancel(ps, r1.get('id'), r1.get('uploadId'))  #分片上传取消

if __name__ == '__main__':

    '''
    返回结果全部是小写的json，原有包含大写字母的key，转换为下划线+小写 如：eTag: e_tag,requestID : request_id.  code为返回的http code
    普通上传正确：
    {u'code': 200, u'name': u'wyll.jpg', u'url': u'http://qinning2.image.alimmdn.com/test/pyt/wyll.jpg', u'request_id': u'07db0514-d7bb-4785-8b34-6697e3aee52f', u'file_size': u'1056344', u'file_modified': 1437535493816, u'e_tag': u'81FCC17FBB190BCA4EC1E9A3DEF02E57', u'message': u'OK', u'mime_type': u'image/jpeg', u'dir': u'/test/pyt'}
    分配正确：
    {u'code': 200, u'name': u'fpinit.jpg', u'part_number': 3, u'upload_id': u'91EB2B4F1DB44BAC97A987D2911D7FE4', u'request_id': u'3d958bc6-b1f5-4462-a230-b731a23296d8', u'message': u'OK', u'id': u'4359abdf-b63f-4cd0-98f5-cdf75d7eb3d5', u'dir': u'/test/pyt', u'e_tag': u'31654C2DD94A50063105357663704B36'}
    错误：
    {u'message': u'InternalError', u'code': 500, u'request_id': u'fe6b0382-c12d-413a-a70b-66745ae76442'}
    '''

    msconds = int(time.time() * 1000) + 3600 * 6000
    ##日常测试
    #ws = Want('xxxx','xxxx')
    #ps = {'detectMime':1,'expiration':msconds,'insertOnly':0,'namespace':'qinning2','sizeLimit':0}

    #线上环境
    ws = Want('xxxx', 'xxxx')
    #正常策略
    ps = {'detectMime': 1, 'expiration': int(time.time() * 1000) + 3600 * 1000, 'insertOnly': 0,
          'namespace': 'qinning2', 'sizeLimit': 0}

    ##无效策略
    #ps = {'detectMime':1,'expiration':msconds,'insertOnly':0,'namespace':'qinning2','sizeLimit':0,'fafa':123}

    #test_upload(ps)
    test_part(ps)